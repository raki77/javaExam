/* profeel 2006 */
package foo;

public class DiceRoller
{
	public static int rollDice() {
		return (int) ((Math.random() *6) +1);
	}
}
