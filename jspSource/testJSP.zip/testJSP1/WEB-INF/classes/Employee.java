package foo;

public class Employee extends MyPerson
{
	private int empID;

	public void setEmpID(int empID) {
		this.empID = empID;
	}

	public int getEmpID() {
		return empID;
	}

}

