/* profeel 2006 */

package foo;

public class Toy
{
	private String name;

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
