import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ClientA {

	/**
	 * @param args
	 */
	JTextField outgoing;
	PrintWriter writer;
	Socket sock;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ClientA().go();
	}
	
	public void go(){
		// gui�� ���� send ��ư�� ���� �����ʸ� ���
		// setUpNetworking() �޼ҵ带 ȣ��.
		JFrame frame = new JFrame("Simple Chat Client");
		JPanel panel = new JPanel();
		outgoing = new JTextField(20);
		JButton button = new JButton("Send");
		button.addActionListener(new buttonListener());
		
		panel.add(outgoing);
		panel.add(button);
		
		frame.getContentPane().add(BorderLayout.CENTER, panel);
		setUpNetworking();
		
		//Thread
		Thread readerThread = new Thread(new IncomingReader());
		readerThread.start();
		
		frame.setSize(400,500);
		frame.setVisible(true);		
	}
	
	private void setUpNetworking() {
		//Socket�� ����� PrintWriter�� ����.
		// �� PrintWriter�� writer �ν��Ͻ� ������ ����.
		try{
			sock = new Socket("127.0.0.1",5000);
			writer = new PrintWriter(sock.getOutputStream());
			System.out.println("networking established");
		}catch (IOException ex) {
			ex.printStackTrace();			
		}
	}
	
	public class buttonListener implements ActionListener {
		public void actionPerformed(ActionEvent ev) {
			try{
				writer.println(outgoing.getText());
				writer.flush();
			}catch(Exception ex) {
				ex.printStackTrace();
			}
			outgoing.setText("");
			outgoing.requestFocus();
		}
	}
	
	
	
	public class IncomingReader implements Runnable {
		public void run(){
			String message;
			try{
				while((message = reader.readLine())!=null) {
					System.out.println("read "+ message);
					incoming.append(message + "\n");
				}
			}catch(Exception ex) {
				ex.printStackTrace();
			}
		}
	}

}
